# Changelog for haskell

## Unreleased changes
